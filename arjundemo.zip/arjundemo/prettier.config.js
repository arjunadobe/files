const config = {
    singleQuote: true,
    tabWidth: 4,
    trailingComma: 'none'
};

module.exports = config;
